<html>
<head>
  <meta charset="UTF-8">
  <script src="lib/jquery/jquery-2.2.4.min.js"></script>
  <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
<?php
$sqlname = "root";
$sqlpassword = "rgukt123";
$hostname = "localhost"; 

$userName=$_POST["username"];
$email=$_POST["email"];
$gender=$_POST["gender"];
$password=$_POST["password"];
$mobile=$_POST["contactNumber"];
$age=$_POST["age"];
$date=date("Y-m-d H:i:s");


//echo $userName;
//connection to the database
$link = mysql_connect($hostname, $sqlname, $sqlpassword) 
  or die("Unable to connect to MySQL");
echo "Connected to MySQL<br>";
mysql_select_db('fristTime');
//for login table




$query="INSERT INTO login (username,email,password,date) VALUES ('$userName','$email','$password','$date')";
$insert=mysql_query($query,$link);
if(mysql_errno()==1062){
	echo "Duplicate record username or email is already exist";
	echo '<br><a href="formPage.html" ><button type="button" class="btn btn-primary btn-xs" >Goback</button></a>';
}
else{
if(!$insert){
	die("Could not insert data".mysql_error());
}
else{
	//echo "Successfully data inserted"
	//$user_id=
	$result = mysql_query("SELECT * FROM login WHERE email = '$email'");
	if(!$result){
	die("Could not found query");}
	$array=mysql_fetch_row($result);
	$user_id=$array[0];
	//echo $user_id;
	$new_query="INSERT INTO users (user_id,name,gender,age,mobile) VALUES ($user_id,'$userName','$gender',$age,'$mobile')";
	//echo $new_query;
	$insert=mysql_query($new_query,$link);
	if(!$insert){
		die("Could not insert into users");
		}
	echo "Successfully inserted into users table";
	mysql_close($link);
}
}
?>
</div>
</body>
</html>
