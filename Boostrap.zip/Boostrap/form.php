<html>
<body>

Welcome dear <?php $naveen=$_POST["one"];echo $naveen; ?><br>
Your email address is:<?php echo $_POST["two"];?><br>
Your mobile number is: <?php echo $_POST["three"];?><br>
You are <?php echo $_POST["four"];?><br>
You are <?php echo $_POST["five"];?> years old<br>
Your password is: <?php echo $_POST["six"];?><br>
</body>
</html>
